var searchData=
[
  ['numberofknobs',['NumberOfKnobs',['../group__KNOBS.html#ga6ea4921d7034f43bb963f4f90b6399dc',1,'KNOB_BASE']]]
];
