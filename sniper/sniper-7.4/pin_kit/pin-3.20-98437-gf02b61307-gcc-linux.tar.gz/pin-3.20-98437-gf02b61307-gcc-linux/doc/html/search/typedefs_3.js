var searchData=
[
  ['debug_5fbreakpoint_5fcallback',['DEBUG_BREAKPOINT_CALLBACK',['../group__APPDEBUG.html#gaee4c44a7173aa62cd5121253d2966b52',1,'debugger_client.PH']]],
  ['debug_5finterpreter_5fcallback',['DEBUG_INTERPRETER_CALLBACK',['../group__APPDEBUG.html#ga3d6a74972d3450e7fb487103f5fe8147',1,'debugger_client.PH']]],
  ['detach_5fcallback',['DETACH_CALLBACK',['../group__PIN__CONTROL.html#ga001c6e9e0cac2ab4ea3ae3d9f5a15fc3',1,'pin_client.PH']]],
  ['detach_5fprobed_5fcallback',['DETACH_PROBED_CALLBACK',['../group__PIN__CONTROL.html#ga2d1917077e6365cb55f94a8cd1747b7f',1,'pin_client.PH']]]
];
