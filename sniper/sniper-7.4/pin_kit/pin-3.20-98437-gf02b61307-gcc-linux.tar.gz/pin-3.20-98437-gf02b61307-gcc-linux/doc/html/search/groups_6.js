var searchData=
[
  ['generic_20modification_20api',['Generic modification API',['../group__INS__MODIFICATION.html',1,'']]]
];
