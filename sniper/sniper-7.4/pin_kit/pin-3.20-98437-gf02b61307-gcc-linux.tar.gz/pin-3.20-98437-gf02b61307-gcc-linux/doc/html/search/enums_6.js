var searchData=
[
  ['knob_5fmode',['KNOB_MODE',['../group__KNOBS.html#ga01b1a33077e2fdfab743da94c406dce3',1,'knob.PH']]]
];
