var searchData=
[
  ['exception_5finfo',['EXCEPTION_INFO',['../structEXCEPTION__INFO.html',1,'']]],
  ['exception_5fspecific',['EXCEPTION_SPECIFIC',['../unionEXCEPTION__INFO_1_1EXCEPTION__SPECIFIC.html',1,'EXCEPTION_INFO']]]
];
