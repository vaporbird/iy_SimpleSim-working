var searchData=
[
  ['undecoration_5fcomplete',['UNDECORATION_COMPLETE',['../group__SYMBOLS.html#gga8b0c33dda59c8d399096714c6307f23da869b5424f40c8d015768c8b0de405d4b',1,'sym_undecorate.PH']]],
  ['undecoration_5fname_5fonly',['UNDECORATION_NAME_ONLY',['../group__SYMBOLS.html#gga8b0c33dda59c8d399096714c6307f23da573ccc7d32ef44f469a6c0f367cbfedf',1,'sym_undecorate.PH']]]
];
