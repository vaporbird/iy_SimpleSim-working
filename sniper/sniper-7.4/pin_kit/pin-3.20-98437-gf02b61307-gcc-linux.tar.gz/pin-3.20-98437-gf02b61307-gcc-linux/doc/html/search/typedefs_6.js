var searchData=
[
  ['get_5femulated_5fregister_5fcallback',['GET_EMULATED_REGISTER_CALLBACK',['../group__APPDEBUG.html#ga9d7745cc697db791f72d06cd149daa72',1,'debugger_client.PH']]],
  ['get_5ftarget_5fdescription_5fcallback',['GET_TARGET_DESCRIPTION_CALLBACK',['../group__APPDEBUG.html#gaf5bdf55a090a9e22c7fdc2efbfac8cb6',1,'debugger_client.PH']]]
];
