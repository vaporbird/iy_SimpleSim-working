var searchData=
[
  ['img_3a_20image_20object',['IMG: Image Object',['../group__IMG.html',1,'']]],
  ['inspection_20api_20for_20ia_2d32_20and_20intel_28r_29_2064_20instructions',['Inspection API for IA-32 and Intel(R) 64 instructions',['../group__INS__INSPECTION.html',1,'']]],
  ['instrumentation_20api',['Instrumentation API',['../group__INS__INSTRUMENTATION.html',1,'']]],
  ['ins_3a_20instruction_20object',['INS: Instruction Object',['../group__INS__REF.html',1,'']]],
  ['instrumentation_20arguments',['Instrumentation arguments',['../group__INST__ARGS.html',1,'']]]
];
