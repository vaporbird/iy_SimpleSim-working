var searchData=
[
  ['level_5fbase',['LEVEL_BASE',['../namespaceLEVEL__BASE.html',1,'']]]
];
