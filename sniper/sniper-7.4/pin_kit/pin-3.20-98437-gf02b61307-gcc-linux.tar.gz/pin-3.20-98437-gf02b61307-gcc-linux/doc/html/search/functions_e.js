var searchData=
[
  ['opcode_5fstringshort',['OPCODE_StringShort',['../group__INS__INSPECTION.html#gaf5f24968bc08823284ca34b5b05e02ac',1,'ins_api_xed_ia32.PH']]],
  ['open',['Open',['../classLOGFILE.html#ac0beeea6ef7460d95ddd8a99b14f5ba6',1,'LOGFILE']]]
];
