var searchData=
[
  ['arch_5fstate_5fsize',['ARCH_STATE_SIZE',['../group__CONTEXT.html#ga15b5de856336b8d0452a63a746bb9c61',1,'reg_ia32.PH']]]
];
