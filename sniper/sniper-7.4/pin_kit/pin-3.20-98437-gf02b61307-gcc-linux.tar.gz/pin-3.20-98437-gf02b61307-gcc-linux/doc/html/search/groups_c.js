var searchData=
[
  ['reg_3a_20register_20object',['REG: Register Object',['../group__REG.html',1,'']]],
  ['replay',['REPLAY',['../group__REPLAY.html',1,'']]],
  ['rtn_3a_20routine_20object',['RTN: Routine Object',['../group__RTN.html',1,'']]]
];
