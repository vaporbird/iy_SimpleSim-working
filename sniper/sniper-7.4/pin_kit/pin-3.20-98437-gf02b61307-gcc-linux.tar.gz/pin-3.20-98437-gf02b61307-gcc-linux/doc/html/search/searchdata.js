var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvwx",
  1: "_acdefhiklmoprsvwx",
  2: "l",
  3: "abcdefghijklmnoprstuvw",
  4: "_abdfikmnprv",
  5: "abcdefgimoprst",
  6: "acdefiklmprsu",
  7: "acdefiklnprsu",
  8: "abcdefgiklmprstu",
  9: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules",
  9: "Pages"
};

