var searchData=
[
  ['fast_20buffering_20apis',['Fast Buffering APIs',['../group__BUFFER.html',1,'']]]
];
