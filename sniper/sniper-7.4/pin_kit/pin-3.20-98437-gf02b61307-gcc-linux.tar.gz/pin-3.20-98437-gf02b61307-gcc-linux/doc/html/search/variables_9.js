var searchData=
[
  ['pin_5finfinite_5ftimeout',['PIN_INFINITE_TIMEOUT',['../namespaceLEVEL__BASE.html#acd4bfdda8db96c83dc44830ac3fa25be',1,'LEVEL_BASE']]],
  ['pin_5fmax_5fthreads',['PIN_MAX_THREADS',['../namespaceLEVEL__BASE.html#aa36119d726090072277fd0ec5ff5f684',1,'LEVEL_BASE']]]
];
